# Markup — arcade update

Public hosted website: https://markup-learn-play-together.brightbunch.chatgpt.site

Open `source/README.md` for controls, development and the arcade changes. `source/AUDIT_REPORT.md` records checks and limitations. `source/docs/previews/` contains screenshots.

`source/` contains the matching reviewed application source. `github-pages/` contains the ready-built static frontend, including `.nojekyll`. Serve it with an HTTP server; opening index.html directly as a file is not supported. Shared rooms use the separately hosted public service.

GitHub Pages still requires the repository's Settings → Pages → Source to be set to GitHub Actions. See `GITHUB_PAGES_SETUP.md` and `Deployment_Status.md`. Do not treat an expected URL as evidence of a live Pages deployment.

Start a new kart race to use the enlarged tracks. Baseline first laps measured 58–62 seconds; items, driving and collisions change actual times. Older active rooms retain their original world geometry.
