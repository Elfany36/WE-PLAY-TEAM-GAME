# Markup — performance update

Public website: https://markup-learn-play-together.brightbunch.chatgpt.site

`source/` contains the matching application source; `github-pages/` contains the ready-built static frontend, including `.nojekyll`. Serve the frontend over HTTP. Shared rooms use the separately hosted public service.

Read `source/README.md` for controls and development instructions, `source/AUDIT_REPORT.md` for the audit and `source/docs/verification/performance-v3.md` for performance changes, measurements and limitations. The site uses authenticated HTTP polling with D1-backed rooms; Internet and device latency cannot be eliminated.

The download retains the learning documentation, three coding modes, eleven casual modes, chat gifts/emoji, all map and board graphics, expanded drawing tools and approximately one-minute new-race kart tracks. The new update optimizes room contention, movement reconciliation and drawing/rendering work.

GitHub Pages must be enabled for the repository: Settings → Pages → Source → GitHub Actions. See `GITHUB_PAGES_SETUP.md` and `Deployment_Status.md`. The separate hosted Site is successfully published; the expected Pages address is not presented as a verified deployment.
